# Zadanie 17. Wielokrotne wyrównanie sekwencji (MSA)

## Treść / cel

Wskaż regiony konserwatywne i zmienne.

## Rozwiązanie

### Regiony silnie konserwowane

Na podstawie sekwencji widoczne są bardzo silnie konserwowane bloki:

- **Około 1-23:** MKTAIIGKGGIGRNPTVEVDLST
- **Około 43-61:** Motyw zawierający ...GPEFVDITG...
- **Około 66-82:** ...NVIFADKT...
- **Około 103-120:** ...GDCPVILVGNKCDL...

### Regiony zmienne

Regiony o dużej zmienności obejmują:
- Około 25-42
- 83-102
- Szczególnie 121-145, gdzie występują **insercje bogate w:**
  - Q/P (glutamina/prolina)
  - G/S (glicyna/seryni)
  - E/D (glutaminowy/aspartowy)
  - K/R (lizyna/arginina)
  - N/T (asparagina/treonina)
  - A/T (alanina/treonina)

- **Końcowe 10-20 reszt** również są zmienne

### Wniosek

- **Rdzeń enzymatyczny** jest konserwowany
- **Pętle/ogony powierzchniowe** tolerują insercje i zmiany składu
