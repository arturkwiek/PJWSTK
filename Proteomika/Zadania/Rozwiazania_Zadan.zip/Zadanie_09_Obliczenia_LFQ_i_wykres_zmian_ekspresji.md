# Zadanie 9. Obliczenia LFQ i wykres zmian ekspresji

## Treść / cel

Oblicz średnie i log2FC.

## Rozwiązanie

| **Białko** | **Śr. kontrola** | **Śr. leczenie** | **Iloraz** | **log2FC** | **Klasyfikacja** |
|---|---|---|---|---|---|
| A | 110.0 | 410.0 | 3.727 | 1.898 | w górę |
| B | 190.0 | 95.0 | 0.500 | -1.000 | w dół |
| C | 52.5 | 53.0 | 1.010 | 0.014 | w górę |
| D | 81.0 | 165.0 | 2.037 | 1.026 | w górę |
| E | 490.0 | 127.5 | 0.260 | -1.942 | w dół |

## Interpretacja

- **A i D** są regulowane **w górę**
- **B i E** są regulowane **w dół**
- **C** praktycznie **bez zmiany** (niewielki dodatni log2FC)

### Obliczenia
Dla każdego białka:
1. log2FC = log₂(Śr. leczenie / Śr. kontrola)
2. Jeśli wartość > 0 → białko wzrasta
3. Jeśli wartość < 0 → białko spada
