# Zadanie 18. Drzewo podobieństwa sekwencji

## Treść / cel

Wskaż klastry.

## Rozwiązanie

### Podobne pary sekwencji

Najbardziej podobne pary według prostego globalnego porównania:
- **B-A:** 91.1% identyczności
- **C-A:** 84.6%
- **C-B:** 82.6%

### Klastry

#### Klaster 1 (główny)
- Seq_A i Seq_B
- Seq_C i Seq_F są do nich relatywnie zbliżone

#### Klaster 2 (oddalony)
- Seq_D, Seq_E i Seq_G
- Bardziej odległy głównie przez **zmienny region środkowo-końcowy**

### Interpretacja

#### Wniosek funkcjonalny
- **Konserwowany rdzeń** sugeruje wspólną funkcję
- **Różne ogony** mogą odpowiadać za:
  - Regulację
  - Lokalizację
  - Oddziaływania specyficzne dla linii

### Ważna uwaga

Drzewo jest **drzewem podobieństwa dla krótkiego zestawu**, a nie pełną filogenezą gatunków.
