# Zadanie 11. Budowa sieci TP53 w STRING

## Treść / cel

Ustaw high confidence 0,700 i do 50 sąsiadów.

## Rozwiązanie

### Prawidłowe parametry
- **Organizm:** Homo sapiens
- **Białko:** TP53
- **Confidence:** ≥0,700
- **Maksymalnie interaktorów:** 50 pierwszego rzędu

### Wymagania sprawozdania
1. Podaj parametry i datę analizy
2. Typowo pojawiają się m.in.:
   - MDM2
   - MDM4
   - ATM
   - CHEK2
   - BRCA1
   - EP300
   - CREBBP
   - BAX
   - CDKN1A
   - GADD45A
   - CASP3
   - AKT1

### Uwaga
Zrzut ekranu jest **częścią rozwiązania praktycznego** i powinien być wygenerowany w STRING.
