# Zadanie 12. Eksploracja sieci TP53

## Treść / cel

Znajdź huby i moduły funkcjonalne.

## Rozwiązanie

### Huby w sieci (przy 50 sąsiadach)
Przykładowe huby: TP53, EP300, AKT1/ATM lub MDM2

Dokładna kolejność zależy od tego, czy liczymy węzeł centralny i od wersji sieci.

### Moduły funkcjonalne

#### MDM2
- Ujemny regulator p53
- Ligaza E3 promująca ubikwitynację i degradację p53
- Onkogen często amplifikowany

#### BRCA1
- Naprawa DNA i kontrola cyklu
- Gen supresorowy związany z rakiem piersi i jajnika

#### Moduł cyklu komórkowego
- CDKN1A
- CCND1
- CDK2
- CHEK1/2

#### Moduł apoptozy
- BAX
- BBC3/PUMA
- PMAIP1/NOXA
- CASP3

#### Moduł naprawy DNA/stresu
- ATM
- ATR
- BRCA1
- RAD51
- GADD45A

### Wniosek
TP53 łączy:
1. Wykrywanie uszkodzeń DNA
2. Zatrzymanie cyklu
3. Naprawę
4. Senescencję i apoptozę
