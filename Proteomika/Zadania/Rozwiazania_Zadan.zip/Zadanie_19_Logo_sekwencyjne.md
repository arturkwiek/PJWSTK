# Zadanie 19. Logo sekwencyjne

## Treść / cel

Zinterpretuj pozycje 60-70.

## Rozwiązanie

### Regiony konserwowane

W regionie około 60-70 dominują reszty należące do **konserwowanego przejścia** między:
- Motywem **DITG**
- Odcinkiem **LKQ...NVIFADKT**

### Wysokie litery w logo

Najwyższe litery powinny obejmować:
- D, I, T, G
- Konserwowane reszty w NVIFADKT

Dokładny skład zależy od **dokładnego numerowania kolumn po MSA**.

### Interpretacja wysokości liter

- **Wysoka litera** = duża częstość aminokwasu i wysoka informacja/konserwacja w danej kolumnie
- **Niskie, wielokolorowe stosy** = zmienność

### Potwierdzenie z poprzedniego zadania

Logo powinno potwierdzić zadanie 17:
- **Wysokie stosy w rdzeniu** (konserwacja)
- **Niskie/rozproszone** w regionach insercyjnych (zmienność)

### Ważna uwaga

Obraz należy **wygenerować samodzielnie z dokładnego MSA**, ponieważ numeracja kolumn zależy od wstawionych luk.
