# Zadanie 20. Korelacja ekspresji RNA i białka TP53

## Treść / cel

cBioPortal: TCGA BRCA, mRNA vs RPPA.

## Rozwiązanie

### Procedura
Po ustawieniu osi należy **przepisać współczynniki** wyświetlane w bieżącej sesji:
- **Współczynnik Pearsona**
- **Współczynnik Spearmana**

### Oczekiwane wyniki

Zwykle **korelacja jest dodatnia, ale słaba lub umiarkowana**.

- **Poziom mRNA** nie wyjaśnia całej zmienności białka p53
- **Dokładna liczba** zależy od:
  - Filtrów
  - Wersji badania
  - Liczby próbek z obiema wartościami

### Przyczyny rozbieżności między mRNA a białkiem p53

1. **Różna wydajność translacji**
2. **Stabilizacja/degradacja białka**
   - p53 jest silnie kontrolowane przez MDM2
3. **Modyfikacje potranslacyjne**
4. **Różny czas życia** RNA i białka
5. **Zmiany liczby kopii i mutacje**
6. **Jakość próbki** i domieszka komórek
7. **Różnice techniczne** między RNA-seq i RPPA

### Wniosek

Należy sformułować na podstawie:
- Wielkości **|r|** (nie tylko znaku)
- **Korelacja nie jest dowodem przyczynowości**

Przykładowa interpretacja: "Słaba/umiarkowana korelacja wskazuje, że inne mechanizmy regulacji (m.in. stabilność białka, modyfikacje potranslacyjne) mają istotny wpływ na poziom p53."
