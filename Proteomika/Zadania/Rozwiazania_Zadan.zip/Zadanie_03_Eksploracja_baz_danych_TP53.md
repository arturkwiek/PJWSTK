# Zadanie 3. Eksploracja baz danych dla TP53

## Treść / cel

PRIDE, PhosphoSitePlus, HPA i PaxDb.

## Rozwiązanie

### A. PRIDE Archive

Odpowiedź zależy od wybranego datasetu. Poprawny opis powinien zawierać:
- identyfikator PXD
- cel doświadczenia
- organizm/próbki
- typ spektrometrii
- listę plików

Jako model: wybierz projekt nowotworowy człowieka, w którym w plikach wynikowych identyfikowane jest P04637/TP53; wskaż pliki surowe aparatu, pliki mzIdentML/mzTab lub wyniki wyszukiwarki i ewentualne pliki FASTA.

### B. PhosphoSitePlus - K120

Lizyna K120 p53 jest przede wszystkim miejscem acetylacji. W zależności od wersji bazy mogą być pokazane również inne modyfikacje lizyny, np. ubikwitynacja lub sumoilacja, jeśli mają potwierdzenie eksperymentalne. W sprawozdaniu należy przepisać dokładnie etykiety widoczne po wskazaniu pinezki.

### C. Human Protein Atlas

- **Główna lokalizacja:** nukleoplazma
- **Dodatkowo:** pęcherzyki i cytozol
- Dla tkanek prawidłowych HPA nie podaje prostego, wiarygodnego rankingu wysokiej ekspresji białka p53; obserwuje się słabe jądrowe i/lub cytoplazmatyczne barwienie w części komórek, a profil jest zależny od typu komórek i stanu biologicznego.

### D. PaxDb

- TP53 ma niską i silnie zależną od zbioru abundancję
- Należy posortować tabelę dla Homo sapiens i podać pierwsze tkanki wraz z jednostką ppm
- Nie należy utożsamiać najwyższej wartości w pojedynczym zbiorze z uniwersalnym „najwyższym poziomem" - p53 jest białkiem regulowanym m.in. przez stabilność i stres komórkowy.
